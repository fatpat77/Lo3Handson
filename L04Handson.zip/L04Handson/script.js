class Employee {
    constructor(name, salary, hireDate) {
      this.name = name;
      this.salary = salary;
      this.hireDate = hireDate;
    }
    getName() {
      console.log(this.name.toUpperCase());
    }
    getSalary() {
      console.log(this.salary);
    }
    getHireDate() {
      console.log(this.hireDate);
    }
  }

  class Manager extends Employee {
    constructor(name, hireDate, salary, descriptionOfJob) {
      super(name, salary, hireDate);
      this.descriptionOfJob = descriptionOfJob;
    }
        jobDescription() {
      console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because he/she " + this.descriptionOfJob + ".");
     }

    }
    class Designer extends Employee {
      constructor (name, hireDate, salary, experience){  
      super(name, salary, hireDate);
      this.experience = experience;
      }
      yearsExperience() {
        console.log (this.name,+ "was hired on" +this.hireDate,+ "and makes" +this.salary,+ "because she" +this.experience+ ".");
    }
  }
    class SalesAssociate extends Employee{
      constructor (name, hireDate, salary, degrees){
      super(name, salary, hireDate);
      this.degrees = degrees;
    }
    
        degreeCompleted() {
    console.log (this.name,+ "was hired on" +this.hireDate,+ "and makes" +this.salary,+"because he" +this.degrees);
     }
  }

    let manager = new Manager("Pat Silva", "2/01/18", "70000", "is the Subsea Supervisor");
    manager.jobDescription();
   
    let designer = new Designer("Martha Kent", "2/23/96", "web slinger", "100000", "is the inventer of the interwebs and cat videos");
    desinger.yearsExperince(); 

    let salesassociate = new SalesAssociate("peter griffith", "2/22/93","100000","phd");
    salesassociate.degreeCompleted();